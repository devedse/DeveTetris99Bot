This is a modified/updated version of the Microsoft HV1 Docbook transform, written by Morten Engelhardt Olsen,

Originally posted at http://sourceforge.net/p/docbook/feature-requests/461/, this has been further updated by Morten to make it compatible with more recent DocBook versions.

 ---------------------------
/ This documentation system \
\   is udderly ridiculous!  /
 ---------------------------
        \   ^__^
         \  (oo)\_______
            (__)\       )\/\
                ||----w |
                ||     ||
